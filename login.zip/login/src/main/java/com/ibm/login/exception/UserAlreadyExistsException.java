package com.ibm.login.exception;

public class UserAlreadyExistsException extends RuntimeException {

}
