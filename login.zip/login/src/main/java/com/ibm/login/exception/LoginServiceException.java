package com.ibm.login.exception;

public class LoginServiceException {

}
