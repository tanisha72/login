package com.ibm.login.exception;

public class UserNotFoundException extends Exception {

	
}
